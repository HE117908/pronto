function hide(x){
     var divsToHide = document.getElementsByClassName("hiding"); //divsToHide is an array
     for(var i = 0; i < divsToHide.length; i++){
        divsToHide[i].style.display = "none";
    }
    document.getElementById(x).style.display = "";
}
var users = ["Jean-Pierre", "Chrisophe", "Albert", "Annette"];

function userUse(x){
    hide(x);
    var usersLen = users.length;
    var text = "<ul>";
    for (i=0;i<usersLen;i++){
        text += "<li>"+users[i]+"</li>";
    }
    text += "</ul>";
    document.getElementById('userList').innerHTML = text;
}

function userAdd(){
    var x = document.getElementById("username").value;
    users.push(x);
    var usersLen = users.length;
    var text = "<ul>";
    for (i=0;i<usersLen;i++){
        text += "<li>"+users[i]+"</li>";
    }
    text += "</ul>";
    document.getElementById('userList').innerHTML = text;
}

var carte = {
    "choix1":{"plat":"Steack", "acompagnement":"frites", "prix":"12€"},
    "choix2":{"plat":"Entrecote", "acompagnement":"frites", "prix":"15€"},
    "choix3":{"plat":"Spaghettis", "acompagnement":"parmesean", "prix":"8€"}
    
}

